package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P3l4asst2bApplicationTests {

	@Test
	void contextLoads() {
	}

}
