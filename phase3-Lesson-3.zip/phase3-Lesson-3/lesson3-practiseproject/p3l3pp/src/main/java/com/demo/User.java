package com.demo;

public class User {
	
	 String username = "seeyo";
	 String password = "";
	 public String username() {
	        return username;
	    }

	    public  String password() {
	        return password;
	    }

}
