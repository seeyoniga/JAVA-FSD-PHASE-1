# docker-elk
Basic ELK stack in Docker
