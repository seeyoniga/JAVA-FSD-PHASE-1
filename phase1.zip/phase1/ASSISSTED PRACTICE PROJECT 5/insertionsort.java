public class insertionsort {  
    public static void sort(int ar[]) {  
        int n = ar.length;  
        for (int i = 1; i < n; i++) {  
            int key = ar[i];  
            int j = i-1;  
            while ( (j > -1) && ( ar [j] > key ) ) {  
                ar [j+1] = ar [j];  
                j--;  
            }  
            ar[j+1] = key;  
        }  
    }  
       
    public static void main(String ar[]){    
        int a[]= {35,12,9,21,3,54};    
        System.out.println("Array before sorting");    
        for(int i:a){    
            System.out.print(i+" ");    
        }    
        System.out.println();    
        sort(a);       
        System.out.println("Array after sorting");    
        for(int i:a){    
            System.out.print(i+" ");    
        }    
    }    
}    