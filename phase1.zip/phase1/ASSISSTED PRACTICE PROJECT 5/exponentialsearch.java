import java.util.*;

public class exponentialsearch {

	public static  void main(String[] args){

		int a[] = {1,3,5,7,9};
		int length= a.length;
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the element to be searched :");
		int key = sc.nextInt();
		int result = es(a,length,key);
		if(result<0){
			System.out.println( "Element is not present in the array");
		}
		else{
			System.out.println( "Element is  present in the array at index :"+result);
		}
	}
	public static int es(int[] arr ,int length, int key ){
		if(arr[0]==key ){
            return 0;
        }
        int n=1;
        while(n<length && arr[n]<=key ){

            n=n*2;
        }
        return Arrays.binarySearch(arr,n/2,Math.min(n,length),key );
	}
}

