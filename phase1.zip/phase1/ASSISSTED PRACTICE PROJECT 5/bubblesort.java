public class bubblesort {  
    static void sort(int a[]) {  
        int n = a.length;  
        int temp = 0; 
        int pass=0;
         for(int i=0; i < n; i++){ 
        	 	pass = pass +1;
                 for(int j=1; j < (n-i); j++){  
                          if(a[j-1] > a[j]){  
                                 //swap elements  
                                 temp = a[j-1];  
                                 a[j-1] = a[j];  
                                 a[j] = temp;  
                         }  
                          
                 }  
         }
         System.out.println("PASSES IT TOOK TO SORT THE ARRAY : "+pass);
    }  
    public static void main(String[] args) {  
                int a[] ={35,12,9,21,3,54};                   
                System.out.println("Array before sorting");  
                for(int i=0; i < a.length; i++){  
                        System.out.print(a[i] + " ");  
                }  
                System.out.println();                   
                sort(a);                 
                System.out.println("Array after sorting");  
                for(int i=0; i < a.length; i++){  
                        System.out.print(a[i] + " ");  
                }
        }  
}  
