import java.util.*;

public class selectionsort {
  void sort(int ar[]) {
    int n = ar.length;
    for (int i=0;i<n-1;i++) {
      int min = i;
      for (int j =i + 1; j < n; j++) {
        if (ar[j] < ar[min]) {
          min = j;
        }
      }
      int temp = ar[i];
      ar[i] = ar[min];
      ar[min] = temp;
    }
  }
  public static void main(String args[]) {
    int a[] = {35,12,9,21,3,54};
    System.out.println("Array before sorting  ");
    System.out.println(Arrays.toString(a));
    selectionsort ss = new selectionsort();
    ss.sort(a);
    System.out.println("Array after sorting  ");
    System.out.println(Arrays.toString(a));
  }
}